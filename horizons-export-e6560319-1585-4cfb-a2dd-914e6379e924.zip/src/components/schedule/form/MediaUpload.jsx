
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Image as ImageIcon, Video as VideoIcon } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

const MediaUpload = ({ mediaFile, setMediaFile, mediaPreview, setMediaPreview, mediaType, setMediaType, postImage }) => {
  const { toast } = useToast();

  const handleMediaChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 20 * 1024 * 1024) { 
        toast({ title: "Arquivo muito grande", description: "O arquivo de mídia não pode exceder 20MB.", variant: "destructive" });
        return;
      }
      setMediaFile(file);
      const fileType = file.type.split('/')[0];
      setMediaType(fileType);
      setMediaPreview(URL.createObjectURL(file));
    }
  };

  return (
    <div>
      <Label htmlFor="post-media" className="text-sm font-medium text-foreground">Mídia (Imagem/Vídeo - JPG, PNG, GIF, MP4 - Máx 20MB)</Label>
      <Input 
        id="post-media" 
        type="file" 
        onChange={handleMediaChange} 
        accept="image/jpeg,image/png,image/gif,video/mp4" 
        className="mt-1 block w-full text-sm text-foreground file:mr-4 file:py-2 file:px-4 file:rounded-md file:border file:border-border file:text-sm file:font-semibold file:bg-muted file:text-primary hover:file:bg-muted/80" 
      />
      {mediaPreview && (
        <div className="mt-2 border border-border rounded-md p-2 bg-muted/50 max-w-xs">
          {mediaType === 'image' && <img  alt="Preview da mídia" class="max-h-40 w-auto rounded" src={mediaPreview} />}
          {mediaType === 'video' && (
            <video controls poster={mediaPreview} className="max-h-40 w-auto rounded">
              <source src={mediaPreview} type={mediaFile?.type || 'video/mp4'} />
              Seu navegador não suporta a tag de vídeo.
            </video>
          )}
        </div>
      )}
      {!mediaPreview && mediaType === 'video' && postImage && (
         <div className="mt-2 border border-border rounded-md p-2 bg-muted/50 max-w-xs flex items-center justify-center h-40">
           <VideoIcon className="h-16 w-16 text-muted-foreground" />
           <p className="ml-2 text-sm text-muted-foreground">Vídeo: {postImage}</p>
         </div>
      )}
      {!mediaPreview && mediaType === 'image' && !postImage && (
          <div className="mt-2 h-20 w-full rounded-md bg-muted flex items-center justify-center border border-dashed border-border">
            <ImageIcon className="h-10 w-10 text-muted-foreground" />
          </div>
      )}
    </div>
  );
};

export default MediaUpload;
