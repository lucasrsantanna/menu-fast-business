
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit2, Trash2, PackagePlus, ArchiveX } from 'lucide-react';

const ProductCard = ({ product, onEdit, onDelete, onToggleStatus, onOpenStockModal }) => {
  const isLowStock = product.controlStock && product.stock > 0 && product.stock < product.lowStockAlert;
  const isOutOfStock = product.controlStock && product.stock === 0;
  const stockDisplay = product.controlStock 
    ? `${product.stock} ${product.unit === 'KG' ? 'kg' : (product.stock === 1 ? 'unidade' : 'unidades')} restantes`
    : "Não controlado";

  return (
    <Card className="overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300 h-full flex flex-col bg-card border-border">
      <div className="relative">
        <img  class="w-full h-48 object-cover" alt={product.name} src="https://images.unsplash.com/photo-1694388001616-1176f534d72f" />
        {product.featured && <Badge variant="default" className="absolute top-2 left-2 bg-yellow-400 text-yellow-900 hover:bg-yellow-500">Destaque</Badge>}
        {product.bestSeller && <Badge variant="secondary" className="absolute top-2 right-2 bg-orange-400 text-orange-900 hover:bg-orange-500">Mais Vendido</Badge>}
        
        {product.controlStock && isLowStock && <Badge variant="destructive" className="absolute bottom-2 right-2 bg-orange-500 text-white">Baixo Estoque</Badge>}
        {product.controlStock && isOutOfStock && <Badge variant="destructive" className="absolute bottom-2 right-2 bg-red-600 text-white">Sem Estoque</Badge>}
        {!product.controlStock && <Badge variant="outline" className="absolute bottom-2 right-2 bg-slate-200 text-slate-700"><ArchiveX className="h-3 w-3 mr-1"/>Não Controlado</Badge>}
      </div>
      <CardHeader className="pb-2 pt-4 px-4">
        <CardTitle className="text-lg font-semibold text-foreground">{product.name}</CardTitle>
        <CardDescription className="text-sm text-muted-foreground">{product.category}</CardDescription>
      </CardHeader>
      <CardContent className="pb-3 px-4 flex-grow">
        <p className="text-xl font-bold text-primary">R$ {product.price}</p>
        <p className="mt-1 text-sm text-muted-foreground">Estoque: {stockDisplay}</p>
        <p className={`mt-1 text-sm font-medium ${product.status === 'Ativo' ? 'text-status-ready' : 'text-destructive'}`}>
          Status: {product.status}
        </p>
      </CardContent>
      <CardFooter className="flex flex-col gap-2 pt-3 pb-4 px-4 border-t border-border mt-auto">
        <div className="flex w-full gap-2">
            <Button variant="outline" size="sm" onClick={onEdit} className="flex-1 border-secondary text-secondary-foreground hover:bg-secondary/20">
                <Edit2 className="mr-2 h-3 w-3" /> Editar
            </Button>
            <Button 
                variant="outline" 
                size="sm" 
                onClick={onOpenStockModal} 
                className="flex-1 border-blue-500 text-blue-500 hover:bg-blue-500/10"
                disabled={!product.controlStock}
            >
                <PackagePlus className="mr-2 h-3 w-3" /> Repor
            </Button>
        </div>
        <div className="flex w-full gap-2">
            <Button 
                variant={product.status === 'Ativo' ? "secondary" : "default"} 
                size="sm" 
                onClick={onToggleStatus} 
                className={`flex-1 ${product.status === 'Ativo' ? 'bg-secondary text-secondary-foreground hover:bg-secondary/80' : 'bg-status-ready text-green-900 hover:bg-status-ready/90'}`}
            >
                {product.status === 'Ativo' ? 'Pausar' : 'Ativar'}
            </Button>
            <Button variant="destructive" size="sm" onClick={onDelete} className="flex-1 bg-destructive text-destructive-foreground hover:bg-destructive/90">
                <Trash2 className="mr-2 h-3 w-3" /> Excluir
            </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default ProductCard;
