
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { PlusCircle } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";
import SchedulePostForm from '@/components/schedule/SchedulePostForm';
import PostList from '@/components/schedule/PostList';
import PostResultsModal from '@/components/schedule/PostResultsModal';
import ScheduleCalendar from '@/components/schedule/ScheduleCalendar';

const initialScheduledPosts = [
  { id: 'sp1', image: 'post1.jpg', text: 'Promoção especial de segunda-feira! Venha conferir nossos pratos com 20% de desconto. #promo #restaurante', dateTime: new Date(2025, 4, 20, 10, 0), status: 'Agendado', platforms: ['facebook', 'instagram'], recurrence: 'once', mediaType: 'image', overrides: { instagram: { format: 'feed' } } },
  { id: 'sp2', image: 'video_promo.mp4', text: 'Novo vídeo promocional! Veja os bastidores da nossa cozinha.', dateTime: new Date(2025, 4, 22, 15, 30), status: 'Publicado', platforms: ['instagram', 'whatsapp'], recurrence: 'once', mediaType: 'video', overrides: { instagram: { format: 'reels' }, whatsapp: { type: 'status' } }, results: { alcance: 1500, impressoes: 2000, cliques: 50, leads: 5, reacoes: 120, dataPublicacaoEfetiva: new Date(2025, 4, 10, 15, 32), interactionsByHour: [{ hour: '09:00', interactions: 10 }, { hour: '12:00', interactions: 30 }, { hour: '18:00', interactions: 50 }] } },
  { id: 'sp3', image: 'post3.jpg', text: 'Happy Hour hoje das 18h às 20h. Drinks em dobro!', dateTime: new Date(2025, 4, 25, 9, 0), status: 'Falhou', platforms: ['facebook'], recurrence: 'weekly', mediaType: 'image', overrides: { facebook: { destination: 'feed' } }, customDates: [new Date(2025,4,25), new Date(2025,5,1)] },
];


const SchedulePostsPage = () => {
  const [scheduledPosts, setScheduledPosts] = useState(initialScheduledPosts);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingPost, setEditingPost] = useState(null);
  const [isResultsModalOpen, setIsResultsModalOpen] = useState(false);
  const [selectedPostForResults, setSelectedPostForResults] = useState(null);
  const { toast } = useToast();

  const handleAddPost = (newPost) => {
    setScheduledPosts(prev => [newPost, ...prev].sort((a, b) => new Date(a.dateTime) - new Date(b.dateTime)));
    setIsFormOpen(false);
    toast({ title: "Sucesso!", description: "Post agendado com sucesso.", className: "bg-status-ready border-status-ready text-white" });
  };

  const handleEditPost = (updatedPost) => {
    setScheduledPosts(prev => prev.map(p => p.id === updatedPost.id ? updatedPost : p).sort((a, b) => new Date(a.dateTime) - new Date(b.dateTime)));
    setIsFormOpen(false);
    setEditingPost(null);
    toast({ title: "Sucesso!", description: "Agendamento atualizado com sucesso." });
  };

  const openEditForm = (post) => {
    setEditingPost(post);
    setIsFormOpen(true);
  };

  const openNewForm = () => {
    setEditingPost(null);
    setIsFormOpen(true);
  };

  const openResultsModal = (post) => {
    setSelectedPostForResults(post);
    setIsResultsModalOpen(true);
  };
  
  const getCombinedPostDates = (post) => {
    let dates = [new Date(post.dateTime)];
    if (post.recurrence === 'custom' && post.customDates && post.customDates.length > 0) {
      dates = [...dates, ...post.customDates.map(d => new Date(d))];
    }
    return dates;
  };

  const postsInCurrentMonth = scheduledPosts.filter(post => {
    const postDates = getCombinedPostDates(post);
    return postDates.some(date => 
        date.getMonth() === currentMonth.getMonth() &&
        date.getFullYear() === currentMonth.getFullYear()
    );
  });

  const daysWithPosts = [...new Set(
    postsInCurrentMonth.flatMap(getCombinedPostDates)
      .filter(date => date.getMonth() === currentMonth.getMonth() && date.getFullYear() === currentMonth.getFullYear())
      .map(date => date.getDate())
  )];


  return (
    <div className="p-4 md:p-6">
      <header className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Agendar Posts</h1>
          <p className="text-muted-foreground">Crie, programe e acompanhe posts para várias redes.</p>
        </div>
        <Dialog open={isFormOpen} onOpenChange={(isOpen) => { setIsFormOpen(isOpen); if (!isOpen) setEditingPost(null); }}>
          <DialogTrigger asChild>
            <Button onClick={openNewForm} className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-md transition-transform hover:scale-105">
              <PlusCircle className="mr-2 h-4 w-4" /> Agendar Post
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-2xl md:max-w-3xl max-h-[90vh] overflow-y-auto p-0 bg-background border-border">
            <DialogHeader className="p-6 pb-0">
              <DialogTitle className="text-2xl font-semibold text-primary">
                {editingPost ? 'Editar Agendamento' : 'Novo Agendamento de Post'}
              </DialogTitle>
              <DialogDescription className="text-muted-foreground">
                {editingPost ? 'Atualize os detalhes do agendamento.' : 'Preencha as informações para o novo post.'}
              </DialogDescription>
            </DialogHeader>
            <div className="p-6">
              <SchedulePostForm 
                post={editingPost} 
                onSubmit={editingPost ? handleEditPost : handleAddPost}
                onCancel={() => { setIsFormOpen(false); setEditingPost(null); }}
              />
            </div>
          </DialogContent>
        </Dialog>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
           <ScheduleCalendar 
             currentMonth={currentMonth}
             setCurrentMonth={setCurrentMonth}
             daysWithPosts={daysWithPosts}
           />
        </div>

        <div className="lg:col-span-1">
          <PostList 
            posts={postsInCurrentMonth} 
            currentMonth={currentMonth}
            onEditPost={openEditForm}
            onViewResults={openResultsModal}
          />
        </div>
      </div>
      
      {selectedPostForResults && (
        <PostResultsModal
          isOpen={isResultsModalOpen}
          onClose={() => setIsResultsModalOpen(false)}
          post={selectedPostForResults}
        />
      )}
    </div>
  );
};

export default SchedulePostsPage;
