
import React, { useState, useEffect } from 'react';
import ProductsHeader from '@/components/products/ProductsHeader';
import ProductsList from '@/components/products/ProductsList';
import ProductForm from '@/components/products/ProductForm';
import StockManagementModal from '@/components/products/StockManagementModal';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from "@/components/ui/use-toast";

const initialProducts = [
  { id: 'p1', name: 'Pizza Margherita', category: 'Pizzas', price: '35.00', status: 'Ativo', image: 'pizza_margherita.jpg', featured: true, bestSeller: false, description: "Clássica pizza Margherita com queijo mussarela fresco e manjericão.", stock: 25, controlStock: true, unit: 'Quantidade', avgUsedPerOrder: 1, lowStockAlert: 10 },
  { id: 'p2', name: 'Hambúrguer Clássico', category: 'Hambúrgueres', price: '25.50', status: 'Ativo', image: 'hamburger_classic.jpg', featured: false, bestSeller: true, description: "Delicioso hambúrguer com carne suculenta, queijo, alface e tomate.", stock: 8, controlStock: true, unit: 'Quantidade', avgUsedPerOrder: 1, lowStockAlert: 5 },
  { id: 'p3', name: 'Coca-Cola Lata', category: 'Bebidas', price: '5.00', status: 'Pausado', image: 'coca_cola.jpg', featured: false, bestSeller: false, description: "Refrigerante Coca-Cola em lata 350ml.", stock: 0, controlStock: true, unit: 'Quantidade', avgUsedPerOrder: 1, lowStockAlert: 20 },
  { id: 'p4', name: 'Salada Caesar', category: 'Saladas', price: '22.00', status: 'Ativo', image: 'salad_caesar.jpg', featured: true, bestSeller: false, description: "Salada Caesar tradicional com frango grelhado e croutons.", stock: 15, controlStock: false, unit: 'KG', avgUsedPerOrder: 0.2, lowStockAlert: 2 },
  { id: 'p5', name: 'Cheesecake de Morango', category: 'Sobremesas', price: '15.00', status: 'Ativo', image: 'cheesecake.jpg', featured: false, bestSeller: false, description: "Fatia de cheesecake cremoso com calda de morango.", stock: 5, controlStock: true, unit: 'Quantidade', avgUsedPerOrder: 1, lowStockAlert: 3 },
];

const categories = ['Pizzas', 'Hambúrgueres', 'Bebidas', 'Saladas', 'Sobremesas', 'Combos'];

const ProductsPage = () => {
  const [products, setProducts] = useState(initialProducts);
  const [searchTerm, setSearchTerm] = useState('');
  const [stockFilter, setStockFilter] = useState('all'); 
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [isStockModalOpen, setIsStockModalOpen] = useState(false);
  const [productForStockUpdate, setProductForStockUpdate] = useState(null);
  const { toast } = useToast();

  const handleAddProduct = (newProduct) => {
    const productWithStockLogic = {
        ...newProduct,
        stock: newProduct.controlStock ? (parseFloat(newProduct.stock) || 0) : 0,
        lowStockAlert: newProduct.controlStock ? (parseFloat(newProduct.lowStockAlert) || 0) : 0,
        avgUsedPerOrder: newProduct.controlStock ? (parseFloat(newProduct.avgUsedPerOrder) || 1) : 0,
    };
    setProducts(prev => [productWithStockLogic, ...prev]);
    setIsFormOpen(false);
    toast({ title: "Sucesso!", description: "Produto adicionado com sucesso.", className: "bg-status-ready border-status-ready text-white" });
  };

  const handleEditProduct = (updatedProduct) => {
     const productWithStockLogic = {
        ...updatedProduct,
        stock: updatedProduct.controlStock ? (parseFloat(updatedProduct.stock) || 0) : 0,
        lowStockAlert: updatedProduct.controlStock ? (parseFloat(updatedProduct.lowStockAlert) || 0) : 0,
        avgUsedPerOrder: updatedProduct.controlStock ? (parseFloat(updatedProduct.avgUsedPerOrder) || 1) : 0,
    };
    setProducts(prev => prev.map(p => p.id === productWithStockLogic.id ? productWithStockLogic : p));
    setIsFormOpen(false);
    setEditingProduct(null);
    toast({ title: "Sucesso!", description: "Produto atualizado com sucesso.", className: "bg-status-ready border-status-ready text-white" });
  };

  const handleDeleteProduct = (productId) => {
    setProducts(prev => prev.filter(p => p.id !== productId));
    toast({ title: "Sucesso!", description: "Produto removido com sucesso.", variant: "destructive" });
  };
  
  const toggleProductStatus = (productId) => {
    setProducts(prev => prev.map(p => p.id === productId ? {...p, status: p.status === 'Ativo' ? 'Pausado' : 'Ativo'} : p));
    toast({ title: "Status Alterado!", description: "O status do produto foi atualizado." });
  };

  const openEditForm = (product) => {
    setEditingProduct(product);
    setIsFormOpen(true);
  };

  const openNewForm = () => {
    setEditingProduct(null);
    setIsFormOpen(true);
  };

  const openStockModal = (product) => {
    if (!product.controlStock) {
        toast({ title: "Aviso", description: "Este produto não tem controle de estoque ativado.", variant: "default"});
        return;
    }
    setProductForStockUpdate(product);
    setIsStockModalOpen(true);
  };

  const handleStockUpdate = (productId, newStockAmount) => {
    setProducts(prev => prev.map(p => p.id === productId ? { ...p, stock: parseFloat(newStockAmount) } : p));
    setIsStockModalOpen(false);
    toast({ title: "Estoque Atualizado!", description: `O estoque do produto ${productForStockUpdate?.name} foi atualizado para ${newStockAmount}.`});
  };

  const debitStockForOrder = (orderedItems) => {
    setProducts(currentProducts => {
        let stockUpdated = false;
        const updatedProducts = currentProducts.map(p => {
            const orderedItem = orderedItems.find(item => item.name === p.name); // Simple match by name for now
            if (orderedItem && p.controlStock && p.stock > 0) {
                const quantityToDebit = orderedItem.quantity * p.avgUsedPerOrder;
                const newStock = Math.max(0, p.stock - quantityToDebit);
                if (p.stock !== newStock) stockUpdated = true;
                return { ...p, stock: newStock };
            }
            return p;
        });
        if (stockUpdated) {
            toast({ title: "Estoque Debitado", description: "Estoque atualizado após finalização do pedido." });
        }
        return updatedProducts;
    });
  };

  useEffect(() => {
    const app = document.getElementById('app-root'); 
    if (app) {
        app.debitStock = debitStockForOrder;
    }
    return () => {
        if(app) delete app.debitStock;
    }
  }, [products]);


  const filteredProducts = products
    .filter(product =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .filter(product => {
      if (stockFilter === 'outOfStock') return product.controlStock && product.stock === 0;
      if (stockFilter === 'lowStock') return product.controlStock && product.stock > 0 && product.stock < product.lowStockAlert;
      if (stockFilter === 'notControlled') return !product.controlStock;
      return true;
    });

  return (
    <div className="flex flex-col h-full">
      <ProductsHeader 
        onNewProductClick={openNewForm} 
        searchTerm={searchTerm}
        onSearchTermChange={setSearchTerm}
        stockFilter={stockFilter}
        onStockFilterChange={setStockFilter}
      />
      
      <Dialog open={isFormOpen} onOpenChange={(isOpen) => { setIsFormOpen(isOpen); if(!isOpen) setEditingProduct(null); }}>
        <DialogContent className="sm:max-w-[625px] max-h-[90vh] overflow-y-auto p-0 bg-background border-border">
          <DialogHeader className="p-6 pb-0">
            <DialogTitle className="text-2xl font-semibold text-primary">
              {editingProduct ? 'Editar Produto' : 'Adicionar Novo Produto'}
            </DialogTitle>
            <DialogDescription className="text-muted-foreground">
              {editingProduct ? 'Atualize os detalhes do produto.' : 'Preencha as informações do novo produto.'}
            </DialogDescription>
          </DialogHeader>
          <div className="p-6">
            <ProductForm 
              product={editingProduct} 
              onSubmit={editingProduct ? handleEditProduct : handleAddProduct}
              onCancel={() => { setIsFormOpen(false); setEditingProduct(null); }}
              categories={categories}
            />
          </div>
        </DialogContent>
      </Dialog>

      {productForStockUpdate && (
        <StockManagementModal
            isOpen={isStockModalOpen}
            onClose={() => setIsStockModalOpen(false)}
            product={productForStockUpdate}
            onStockUpdate={handleStockUpdate}
        />
      )}
      
      <ProductsList 
        products={filteredProducts}
        onEditProduct={openEditForm}
        onDeleteProduct={handleDeleteProduct}
        onToggleStatus={toggleProductStatus}
        onOpenStockModal={openStockModal}
      />
    </div>
  );
};

export default ProductsPage;

// Expose debitStockForOrder globally for DashboardPage to call (simplified inter-component communication)
// In a larger app, this would be handled via context or a state management library.
// This is a workaround for the current setup.
export const debitStockFromProductsPage = (orderedItems) => {
    const appRoot = document.getElementById('app-root');
    if (appRoot && appRoot.debitStock) {
        appRoot.debitStock(orderedItems);
    }
};
